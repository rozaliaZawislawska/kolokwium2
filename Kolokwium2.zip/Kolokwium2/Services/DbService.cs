﻿using Kolokwium2.Models;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Context;

namespace Kolokwium2.Services;
public interface IDbService
    {
        public Task<List<Sale>> getClientWithSubscrption(int clientId);
        public Task<int> addPayments(int IdClient,int IdSubscription, Payment payment);
    }

public class DbService : IDbService
{
    private readonly MyDbContext _myDbContext;

    public DbService(MyDbContext myDbContext)
    {
        _myDbContext = myDbContext;
    }
    
    public async Task<List<Sale>> getClientWithSubscrption(int clientId)
    {
        return await _myDbContext.Sales
            .Include(e => e.Client)
            .Include(e => e.Subscription)
            .Where(e => e.Client.IdClient == clientId)
            .ToListAsync();
    }

    public async Task<int> addPayments(int IdClient, int IdSubscription, Payment payment)
    {
        
        await _myDbContext.Payments.AddAsync(new Payment()
        {
            IdClient = IdClient,
            IdSubscription = IdSubscription,
            IdPayment = payment.IdPayment,
            Date = payment.Date
        });
        await _myDbContext.SaveChangesAsync();
        return payment.IdPayment;
    }
}

