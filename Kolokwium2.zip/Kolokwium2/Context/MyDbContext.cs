using Kolokwium2.Models;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Context;

public class MyDbContext: DbContext
{
    public MyDbContext()
    {
        
    }
    
    public MyDbContext(DbContextOptions<MyDbContext> options):base(options)
    {
        
    }
    
    public DbSet<Client> Clients { get; set; }
    public DbSet<Discount> Discounts { get; set; }
    public DbSet<Payment> Payments { get; set; }
    public DbSet<Sale> Sales { get; set; }
    public DbSet<Subscription> Subscriptions { get; set; }
    
}