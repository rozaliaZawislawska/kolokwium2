﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kolokwium2.Models;

[Table("Discount")]
public class Discount
{
    [Key]
    [Required]
    public int IdDiscount { set; get; }
    [Required]
    public int Value { set; get; }
    [Required]
    public int IdSubscription { set; get; }
    [ForeignKey(nameof(IdSubscription))]
    public virtual Subscription Subscription { get; set; }
    [Required]
    public DateTime DateFrom { set; get; }
    [Required]
    public DateTime DateTo { set; get; }
}