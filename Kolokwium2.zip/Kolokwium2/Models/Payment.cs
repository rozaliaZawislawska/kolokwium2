﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kolokwium2.Models;

[Table("Payment")]
public class Payment
{
    [Key]
    [Required]
    public int IdPayment { set; get; }
    [Required]
    public DateTime Date { set; get; }
    [Required]
    public int IdClient { set; get; }
    [ForeignKey(nameof(IdClient))]
    public virtual Client Client { get; set; }
    [Required]
    public int IdSubscription { set; get; }
    [ForeignKey(nameof(IdSubscription))]
    public virtual Subscription Subscription { get; set; }
    
}