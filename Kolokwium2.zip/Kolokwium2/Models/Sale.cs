﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kolokwium2.Models;

[Table("Sale")]
public class Sale
{
    [Key]
    [Required]
    public int IdSale { set; get; }
    [Required]
    public int IdClient { set; get; }
    [ForeignKey(nameof(IdClient))]
    public virtual Client Client { get; set; }
    [Required]
    public int IdSubscription { set; get; }
    [ForeignKey(nameof(IdSubscription))]
    public virtual Subscription Subscription { get; set; }
    [Required]
    public DateTime CreatedAt { set; get; }
    
    
}