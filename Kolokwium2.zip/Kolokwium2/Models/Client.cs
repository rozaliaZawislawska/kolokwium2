﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;

namespace Kolokwium2.Models;

[Table("Client")]
public class Client
{
    [Key]
    [Required]
    public int IdClient { set; get; }
    [Required][MaxLength(100)]
    public string FirstName { set; get; }
    [Required][MaxLength(100)]
    public string LastName { set; get; }
    [Required][MaxLength(100)]
    public string Email { set; get; }
    [MaxLength(100)]
    public string? Phone { set; get; }
    
}

