﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kolokwium2.Models;

[Table("Subscription")]
public class Subscription
{
    [Key]
    [Required]
    public int IdSubscription { set; get; }
    [Required][MaxLength(100)]
    public string Name { set; get; }
    [Required][AllowedValues(1,3,6)]
    public int RenewalPeriod { set; get; }
    [Required]
    public DateTime EndTime { set; get; }
    [Required]
    public double Price { set; get; }
}