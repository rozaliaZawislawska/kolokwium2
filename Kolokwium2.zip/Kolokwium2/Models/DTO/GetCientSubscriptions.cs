﻿namespace Kolokwium2.Models.DTO;

public class GetClientSubscriptions
{
    public string Firstname { get; set; }
    public string LastName { get; set; } 
    public string Email { get; set; }
    public string phone { get; set; }
    
    public ICollection<GetSubscription> Subscriptions { get; set; }
}

public class GetSubscription
{
    public int IdSubscription { set; get; }
    public string Name { set; get; }
    public int TotalPaidAmount { set; get; }
}