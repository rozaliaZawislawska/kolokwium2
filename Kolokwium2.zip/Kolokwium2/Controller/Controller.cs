using Kolokwium2.Models.DTO;
using Kolokwium2.Services;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Context;

namespace WebApplication1.Controller;

[Route("api/[controller]")]
[ApiController]
public class Controller: ControllerBase
{
    public MyDbContext _dbContext;
    public DbService _dbService;

    public Controller(MyDbContext dbContext, DbService dbService)
    {
        _dbContext = dbContext;
        _dbService = dbService;
    }
    
    [HttpGet("{clientId}/subscription")]
    public async Task<IActionResult> GetClientsOrders(int clientId)
    {
        var orders = await _dbService.getClientWithSubscrption(clientId);

        return Ok(orders.Select(e => new GetClientSubscriptions()
        {
            Firstname = e.Client.FirstName,
            LastName = e.Client.LastName,
            Email = e.Client.Email,
            phone = e.Client.Phone,
            Subscriptions = e.Subscription.Select(p => new GetSubscription()
            {
                IdSubscription = p.Subscription.IdSubscription,
                Name = p.Subscription.Name,
                TotalPaidAmount = p.Subscription.RenewalPeriod
            }).ToList()
         
        }));
    }
    
    
    
    
}